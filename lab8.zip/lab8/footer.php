<hr>
    
        <footer>
            <p>&copy; 2025 My Website. All rights reserved.</p>
            <nav>
                <ul>
                    <li><a href="privacy.php">Privacy Policy</a></li>
                    <li><a href="terms.php">Terms of Service</a></li>
                </ul>
            </nav>
        </footer>
</body>
</html>